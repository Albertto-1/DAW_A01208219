BULK INSERT Materiales
   FROM 'e:\wwwroot\a1208219\materiales.csv'
   WITH
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )

