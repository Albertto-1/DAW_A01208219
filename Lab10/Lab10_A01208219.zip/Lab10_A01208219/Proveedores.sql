BULK INSERT Proveedores
   FROM 'e:\wwwroot\a1208219\proveedores.csv'
   WITH
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )