BULK INSERT Proyectos
   FROM 'e:\wwwroot\a1208219\proyectos.csv'
   WITH
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )
